"""
The contents of 'extrafiles' are zipped and uploaded first. Then unpacked at runtime.
"""
from .timeteller import TimeTeller