import datetime
from pathlib import Path

import pandas as pd

csv_path = Path(__file__).parent / "data.csv"

class TimeTeller:

    @classmethod
    def tell_time(cls) -> str:
        """
        Fetches the current date and time, gets the weekday in Dutch and returns a
        string containing the Dutch weekday along with the current time.
        """
        now_time = datetime.datetime.now()
        now_day = now_time.weekday()

        dates_df = pd.read_csv(csv_path, index_col=0)
        dutch_weekday = dates_df['dag'].to_dict().get(now_day)

        return f"Het is {dutch_weekday}, {now_time:%H:%M} uur."
